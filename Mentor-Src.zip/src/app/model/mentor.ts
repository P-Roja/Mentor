export class mentor{
    userName:string;
    email:string;
    password:string;
    gender:string;
    address:string;
    contactNumber:string;
    role:string;
    linkedinUrl :string;
    trainingCompleted :string;
    skills:string;
    yearOfExperience: string;
    slotTime : string;

}