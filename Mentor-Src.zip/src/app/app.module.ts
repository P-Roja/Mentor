import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule} from '@angular/forms';


import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { UserRegistrationComponent } from './user-registration/user-registration.component';
import { LoginComponent } from './login/login.component';
import { HttpClient, HttpClientModule } from '@angular/common/http';
import { MentorRegistrationComponent } from './mentor-registration/mentor-registration.component';
import { UserLandingComponent } from './user-landing/user-landing.component';
import { MentorLandingComponent } from './mentor-landing/mentor-landing.component';
import { AdminLandingComponent } from './admin-landing/admin-landing.component';

@NgModule({
  declarations: [
    AppComponent,
    UserRegistrationComponent,
    LoginComponent,
    MentorRegistrationComponent,
    UserLandingComponent,
    MentorLandingComponent,
    AdminLandingComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule    
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
